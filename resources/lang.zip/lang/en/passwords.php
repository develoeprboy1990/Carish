<?php

return array (
  'change_password' => 'Change the password',
  'change_password_below' => 'Change your password below for',
  'confirm_password_not_match' => 'Passwords do not match.',
  'confirm_passwrord' => 'Confirm the password',
  'current_password' => 'Current Password',
  'forgot_password' => 'Forgot the password',
  'new_password' => 'New password',
  'old_password_not_match' => 'Old password does not match.',
  'password' => 'Passwords must be at least eight characters long and match the confirmation.',
  'reset' => 'Your password has been reset!',
  'retype_new_password' => 'Re-type the new password',
  'sent' => 'We have e-mailed your password reset link!',
  'token' => 'This password reset token is invalid.',
  'user' => 'We can\'t find a user with that e-mail address.',
);
