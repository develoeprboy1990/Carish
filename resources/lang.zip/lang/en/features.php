<?php

return array (
  'offer_services_information' => 'Services information',
  'post_an_offer_service' => 'Offer a service',
);
