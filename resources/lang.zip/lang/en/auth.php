<?php

return array (
  'by_clicking_the_button' => 'By clicking the button above, you are agreeing to our',
  'create_account' => 'Create an account',
  'failed' => 'These credentials do not match our records.',
  'login_link' => 'Sign in',
  'sign_out' => 'Sign out',
  'signup_link' => 'Sign up',
  'terms_of_use' => 'Terms Of Use.',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
);
