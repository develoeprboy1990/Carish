<?php

return array (
  'first_name' => 'First name',
  'login_link' => 'Log in',
  'register' => 'Register label in English',
  'signup_link' => 'Sign up',
  'welcome' => 'Welcome to our application',
);
