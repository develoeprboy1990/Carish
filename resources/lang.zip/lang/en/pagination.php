<?php

return array (
  'next' => 'Next',
  'pagenumber' => 'Page no.',
  'previous' => 'Previous',
);
