<?php

return array (
  'back_to_dashboard' => 'Back To Dashboard',
  'change_password' => 'Change the password',
  'edit_profile' => 'Edit profile',
  'first_name' => 'First name',
  'full_name' => 'Full name',
  'member_since' => 'Member since',
  'my_profile' => 'My profile',
  'phone' => 'Phone',
  'prefered_language' => 'Preferred Language',
  'register' => 'Register Label In English',
  'save_changes' => 'Save changes',
  'select_city' => 'Select a city',
  'welcome' => 'Welcome to our application',
);
