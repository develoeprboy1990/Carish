<?php

return array (
  'first_name' => 'First name',
  'register' => 'Register label in English',
  'welcome' => 'Welcome to our application',
);
