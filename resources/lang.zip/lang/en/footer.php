<?php

return array (
  'allrightsreserved' => 'All Rights Reserved.',
  'already_subscribe' => 'Already Subscribe!',
  'call' => 'Call',
  'click_here' => 'Click here',
  'copyright' => 'Copyright',
  'follow' => 'Follow us on',
  'privacy' => 'Privacy Policy',
  'subscribe' => 'Subscribe',
  'subscribetoournewsletter' => 'Subscribe to our newsletter!',
  'termsofservice' => 'Terms Of Service',
  'thank_you_for_your_subscription' => 'Thank you for your subscription!',
  'to_unsubscribe' => 'To unsubscribe',
  'us' => 'us',
);