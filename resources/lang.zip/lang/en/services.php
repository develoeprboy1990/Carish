<?php

return array (
  'first_name' => 'First Name',
  'offer_services_information' => 'Offered services information',
  'post_an_offer_service' => 'Post an offer for service',
  'register' => 'Register Label In English',
  'welcome' => 'Welcome to our application',
);
