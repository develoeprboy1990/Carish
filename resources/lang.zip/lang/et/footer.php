<?php

return array (
  'allrightsreserved' => 'Kõik õigused kaitstud',
  'already_subscribe' => 'Telli juba!',
  'call' => 'Helistama',
  'click_here' => 'Klõpsa siia',
  'copyright' => 'Autoriõigused',
  'follow' => 'Jälgi meid',
  'privacy' => 'Privaatsuspoliitika',
  'subscribe' => 'Telli',
  'subscribetoournewsletter' => 'Liitu meie uudiskirjaga!',
  'termsofservice' => 'Kasutustingimused',
  'thank_you_for_your_subscription' => 'Täname uudiskirjaga liitumast!',
  'to_unsubscribe' => 'Uudiskirja tellimuse lõpetamiseks',
  'us' => 'meie',
);