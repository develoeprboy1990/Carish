<?php

return [

	/*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

'compare_specifications'       => 'Võrdle spetsifikatsioone',
'overall_length'     =>'Üldpikkus',
'overall_width'   =>'Üldlaius',
'overall_height'=>'Üldkõrgus',
'assembly'=> 'Kokkupanek',
'transmission_type'=> 'Käigukasti tüüp',
'fuel_type'=> 'kütuse tüüp',
'fuel_average'=>'Kütusekulu',
'engine_capacity'=> 'Mootori töömaht',
'engine_power'=>'Mootorivõimsus',
'view_more'=>'Vaata rohkem',
'free'=>'Tasuta',
'compare_features'=>'Võrdle funktsioone',
'postan_ad_for'=> 'Postita kuulutus',
'sell_it_faster_to'=> 'Müü kiiremini tuhandetele ostjatele',
'sell_your_car'=> 'MÜÜ OMA AUTO',
'cars_comparison'=>'Autode võrdlus',
'confused'=> 'Segaduses? Võrdle valitud autosid',
'select_car'=> 'Vali auto',
'clear'=>'Eemalda',
'my_saved_ads'=>'Salvestatud kuulutused',
    'new_car_comparison'=>'Uute autode võrdlus',
    'cars'=>'Autod'
    

];
