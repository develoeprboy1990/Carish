<?php

return array (
  'first_name' => 'Nimi',
  'login_link' => 'Logi sisse',
  'register' => 'Registreeritud Eestis',
  'signup_link' => 'Registreeri',
  'welcome' => 'Tere tulemast!',
);
