<?php

return [

'post_an_offer_service' => 'Paku teenust',
'offer_services_information' => 'Paku teenuseinfot'
];
