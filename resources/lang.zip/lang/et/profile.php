<?php

return array (
  'back_to_dashboard' => 'Tagasi juhtpaneeli juurde',
  'change_password' => 'Muuda salasõna',
  'edit_profile' => 'Muuda profiili',
  'first_name' => 'Nimi',
  'full_name' => 'Täisnimi',
  'member_since' => 'Liige alates',
  'my_profile' => 'Minu profiil',
  'phone' => 'Telefon',
  'prefered_language' => 'Eelistatud keel',
  'register' => 'Registreeritud Eestis',
  'save_changes' => 'Salvesta muudatused',
  'select_city' => 'Vali linn',
  'welcome' => 'Tere tulemast!',
);
