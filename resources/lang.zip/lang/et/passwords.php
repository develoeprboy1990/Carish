<?php

return array (
  'change_password' => 'Muuda salasõna',
  'change_password_below' => 'Muuda oma parooli allpool',
  'confirm_password_not_match' => 'Sisestatud paroolid ei ühti',
  'confirm_passwrord' => 'Kinnita salasõna',
  'current_password' => 'Praegune salasõna',
  'forgot_password' => 'Unustasid salasõna?',
  'new_password' => 'Uus salasõna',
  'old_password_not_match' => 'Vale vana salasõna',
  'password' => 'Salasõna peab sisaldama vähemalt 8 tähemärki.',
  'reset' => 'Salasõna on edukalt lähtestatud!',
  'retype_new_password' => 'Sisesta uus salasõna uuesti',
  'sent' => 'Salasõna lähtestamise link on saadetud teie postkastile!',
  'token' => 'Salasõna lähtestamise tunnus on kehtetu.',
  'user' => 'Sisestatud emaili aadressiga kasutajat ei leitud.',
);
