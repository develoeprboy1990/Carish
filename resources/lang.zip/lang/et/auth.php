<?php

return array (
  'by_clicking_the_button' => 'Ülaltoodud nupul klõpsates nõustud meie',
  'create_account' => 'Loo konto',
  'failed' => 'Valed sisselogimisandmed',
  'login_link' => 'Logi sisse',
  'sign_out' => 'Logi välja',
  'signup_link' => 'Loo konto',
  'terms_of_use' => 'Kasutustingimused',
  'throttle' => 'Liiga palju sisselogimiskatseid. Proovige uuesti :seconds sekundi pärast.',
);
