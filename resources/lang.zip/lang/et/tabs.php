<?php

return array (
  'first_name' => 'Nimi',
  'register' => 'Registreeritud Eestis',
  'welcome' => 'Tere tulemast!',
);
