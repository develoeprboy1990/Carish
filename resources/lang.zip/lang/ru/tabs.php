<?php

return array (
  'first_name' => 'Имя',
  'register' => 'Зарегистрировать',
  'welcome' => 'Добро пожаловать!',
);
