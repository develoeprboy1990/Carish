<?php

return array (
  'next' => 'Далее',
  'pagenumber' => 'Номер страницы',
  'previous' => 'Назад',
);
