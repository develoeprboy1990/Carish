<?php

return array (
  'back_to_dashboard' => 'Вернуться к панели управления',
  'change_password' => 'Сменить пароль',
  'edit_profile' => 'Редактировать профиль',
  'first_name' => 'Имя',
  'full_name' => 'Имя, фамилия',
  'member_since' => 'Пользователь с',
  'my_profile' => 'Мой профиль',
  'phone' => 'Телефон',
  'prefered_language' => 'Предпочетаемый язык',
  'register' => 'Зарегистрировать',
  'save_changes' => 'Сохранить изменения',
  'select_city' => 'Выберите город',
  'welcome' => 'Добро пожаловать!',
);
