<?php

return array (
  'first_name' => 'Имя',
  'register' => '',
  'welcome' => 'Добро пожаловать!',
);
