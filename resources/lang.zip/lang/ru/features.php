<?php

return [

'post_an_offer_service' => 'Предложить услугу',
'offer_services_information' => 'Предложить информацию об услуге'
];
