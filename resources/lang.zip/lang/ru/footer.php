<?php

return array (
  'allrightsreserved' => 'Все права защищены',
  'already_subscribe' => 'Уже подписаться!',
  'call' => 'Вызов',
  'click_here' => 'Нажмите сюда',
  'copyright' => 'Авторские права',
  'follow' => 'Подпишитесь на нас в',
  'privacy' => 'Политика конфиденциальности',
  'subscribe' => 'Подписаться',
  'subscribetoournewsletter' => 'Подписывайтесь на нашу новостную рассылку!',
  'termsofservice' => 'Правила пользования',
  'thank_you_for_your_subscription' => 'Спасибо за подписку!',
  'to_unsubscribe' => 'Отписаться от подписки',
  'us' => 'нас',
);