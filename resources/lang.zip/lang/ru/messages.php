<?php

return array (
  'first_name' => 'Имя',
  'login_link' => 'Войти',
  'register' => 'Зарегистрировать',
  'signup_link' => 'Зарегистрироваться',
  'welcome' => 'Добро пожаловать!',
);
